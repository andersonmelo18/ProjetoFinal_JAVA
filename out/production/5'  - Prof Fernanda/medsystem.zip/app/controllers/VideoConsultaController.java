package app.controllers;

import app.database.FakeDB;
import app.database.ConsultaStorage;
import app.models.Consulta;
import app.models.Usuario;

public class VideoConsultaController {
    public static void iniciar(Usuario user) {
        for (Consulta c : FakeDB.consultas) {
            if (c.getEmailUsuario().equals(user.getEmail()) && c.getTipo().equalsIgnoreCase("video") && !c.isRealizada()) {
                c.setRealizada(true);
                ConsultaStorage.saveConsultas();
                return;
            }
        }
    }
}
