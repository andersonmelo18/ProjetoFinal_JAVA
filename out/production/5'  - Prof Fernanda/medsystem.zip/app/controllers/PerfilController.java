package app.controllers;

import app.models.Usuario;

public class PerfilController {
    public static void mostrar(Usuario user) {
        System.out.println(user.getNome());
        System.out.println(user.getEmail());
    }
}
