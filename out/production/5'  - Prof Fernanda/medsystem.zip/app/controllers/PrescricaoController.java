package app.controllers;

public class PrescricaoController {
    public static void exibir() {
        System.out.println("Amoxicilina 500mg");
        System.out.println("1 comprimido a cada 8h por 7 dias");
    }
}
