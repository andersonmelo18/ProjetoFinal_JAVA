package app.controllers;

import app.database.FakeDB;
import app.database.ConsultaStorage;
import app.models.Consulta;
import app.models.Usuario;
import java.util.Scanner;

public class AgendamentoController {
    public static void agendar(Usuario user, Scanner sc) {
        String data = sc.nextLine();
        String tipo = sc.nextLine();
        Consulta c = new Consulta(user.getEmail(), data, tipo);
        FakeDB.consultas.add(c);
        ConsultaStorage.saveConsultas();
    }
}
