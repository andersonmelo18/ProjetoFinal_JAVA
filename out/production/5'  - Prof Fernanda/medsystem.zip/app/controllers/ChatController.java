package app.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ChatController {
    private static final List<String> mensagens = new ArrayList<>();

    public static void enviarMensagem(Scanner sc) {
        String msg = sc.nextLine();
        mensagens.add("Você: " + msg);
        mensagens.add("Médico: Mensagem recebida");
    }

    public static void listar() {
        for (String m : mensagens) System.out.println(m);
    }
}
