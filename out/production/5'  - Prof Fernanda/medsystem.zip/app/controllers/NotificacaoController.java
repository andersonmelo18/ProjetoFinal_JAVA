package app.controllers;

public class NotificacaoController {
    public static void lembretes() {
        System.out.println("Consulta amanhã.");
        System.out.println("Tome água regularmente.");
    }
}
