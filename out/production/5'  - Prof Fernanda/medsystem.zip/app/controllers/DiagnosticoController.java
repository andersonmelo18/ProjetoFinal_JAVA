package app.controllers;

import app.models.Usuario;
import java.util.Scanner;

public class DiagnosticoController {
    public static void realizarDiagnostico(Usuario user, Scanner sc) {
        String sintomas = sc.nextLine();
        System.out.println("Diagnóstico preliminar: possível gripe.");
    }
}
