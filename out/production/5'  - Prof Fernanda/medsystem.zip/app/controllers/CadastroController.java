package app.controllers;

import app.database.FakeDB;
import app.database.UserStorage;
import app.models.Usuario;
import java.util.Scanner;

public class CadastroController {
    public static Usuario cadastrar(Scanner sc) {
        String nome = sc.nextLine();
        String email = sc.nextLine();
        String senha = sc.nextLine();
        for (Usuario u : FakeDB.usuarios) {
            if (u.getEmail().equalsIgnoreCase(email)) return null;
        }
        Usuario novo = new Usuario(nome, email, senha);
        FakeDB.usuarios.add(novo);
        UserStorage.saveUsers();
        return novo;
    }
}
