package app;

import app.controllers.*;
import app.database.FakeDB;
import app.models.Usuario;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        FakeDB.init();
        Scanner sc = new Scanner(System.in);
        Usuario user = null;

        while (user == null) {
            int op = sc.nextInt(); sc.nextLine();
            if (op == 1) user = LoginController.login(sc);
            else user = CadastroController.cadastrar(sc);
        }

        while (true) {
            int op = sc.nextInt(); sc.nextLine();
            switch (op) {
                case 1 -> DiagnosticoController.realizarDiagnostico(user, sc);
                case 2 -> AgendamentoController.agendar(user, sc);
                case 3 -> VideoConsultaController.iniciar(user);
                case 4 -> ChatController.enviarMensagem(sc);
                case 5 -> ChatController.listar();
                case 6 -> NotificacaoController.lembretes();
                case 7 -> PrescricaoController.exibir();
                case 8 -> HistoricoController.listar(user);
                case 9 -> PerfilController.mostrar(user);
                case 10 -> { return; }
            }
        }
    }
}
